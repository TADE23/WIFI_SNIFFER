#include <stdio.h>			 //For standard things
#include <stdlib.h>			 //malloc
#include <string.h>			 //memset
#include <netinet/ip_icmp.h> //Provides declarations for icmp header
#include <netinet/udp.h>	 //Provides declarations for udp header
#include <netinet/tcp.h>	 //Provides declarations for tcp header
#include <netinet/ip.h>		 //Provides declarations for ip header
#include <sys/socket.h>
#include <arpa/inet.h>
#include "src/header.h"
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/wait.h>

int main()
{

	// start sniffing in another process
	pid_t child_pid = fork();

	if (child_pid == 0) {
		sniffer();
	}
	//----------------------------------

	if (child_pid > 0)
	{	
		// variables-------------------------------
		char input_command[NUM_OF_CHAR_IN_COMMAND];
		//-----------------------------------------

		while (1)
		{
			puts("enter command : ");
			fgets(input_command, NUM_OF_CHAR_IN_COMMAND, stdin);

			// start receiving------------------------------------
			if (0 == strncmp(input_command, "start", 5))
			{
				puts("entered comand is - start\n");
				kill(child_pid, SIGCONT);

				continue;
			}
			//----------------------------------------------------

			// stop receiving-------------------------------------
			if (0 == strncmp(input_command, "stop", 4))
			{
				puts("entered comand is - stop\n");
				kill(child_pid, SIGSTOP);

				continue;
			}
			//----------------------------------------------------

			// get help-------------------------------------------
			if (0 == strncmp(input_command, "--help", 6))
			{
				about_prog();

				continue;
			}
			//----------------------------------------------------

			// exit from the program------------------------------
			if (0 == strncmp(input_command, "break", 5))
			{

				char command[6];
				sprintf(command, "sudo kill -9 %d", child_pid, 6);
				system(command);

				break;
			}
			//----------------------------------------------------

			// num of packets-------------------------------------
			if (0 == strncmp(input_command, "show", 4))
			{
				FILE *write_command = fopen("num_of_packets.txt", "w");

				fprintf(write_command, input_command);

				fclose(write_command);

				continue;
			}
			//----------------------------------------------------

			// stat-----------------------------------------------
			if (0 == strncmp(input_command, "stat", 4))
			{
				char s[100];
				int k = 0;
				FILE *stat = fopen("data.txt", "r");

				while (fgets(s, 100, stat))
				{
					printf("%s", s);
					k++;
				}

				printf("\n\nnum of line = %d\n", k);

				fclose(stat);

				continue;
			}
			//----------------------------------------------------

			puts("Doesn't exist such command\n");
		}
	}

	return 0;
}
