
#ifndef HEADER_SN
#define HEADER_SN

//user define---------
#define NUM_OF_CHAR_IN_COMMAND 7
//--------------------

//IP list struct--------------------------------------------------------
typedef struct IP_list{
    char* IP;
    unsigned num_of_packets;
    
    struct IP_list* next;
} IP_list;

IP_list* createNodeForIPList(char* set_IP, unsigned set_num_of_packets);
IP_list* pushNodeFront(IP_list** existing_IP_list, char* set_IP, unsigned set_num_of_packets);
void printIPList(IP_list* IP_list_to_print);
//----------------------------------------------------------------------

//sniffer func-------------------------------------------------------------------
void sniffer();
void print_ip_header(unsigned char *Buffer, int Size, IP_list *existing_IP_list);
void about_prog();
//-------------------------------------------------------------------------------

#endif // HEADER_SN