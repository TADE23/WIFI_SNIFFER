#include <stdio.h>			 //For standard things
#include <stdlib.h>			 //malloc
#include <string.h>			 //memset
#include <netinet/ip_icmp.h> //Provides declarations for icmp header
#include <netinet/udp.h>	 //Provides declarations for udp header
#include <netinet/tcp.h>	 //Provides declarations for tcp header
#include <netinet/ip.h>		 //Provides declarations for ip header
#include <sys/socket.h>
#include <arpa/inet.h>
#include "header.h"

// global variables---------------------------------------------------
int sock_raw;
FILE *logfile;
struct sockaddr_in source, dest;

char *sour;
//--------------------------------------------------------------------

void sniffer()
{
	// variable--------------------------------------------------------
	int saddr_size, data_size;
	struct sockaddr saddr;
	struct in_addr in;

	unsigned char *buffer = (unsigned char *)malloc(65536);

	IP_list *existing_IP_list = createNodeForIPList("num of packets = ", 0);
	//----------------------------------------------------------------

	// open file-------------------------
	logfile = fopen("data.txt", "a");

	if (logfile == NULL) {
		printf("Unable to create file.");
	}
	//-----------------------------------

	// Create a raw socket that shall sniff--------------
	sock_raw = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
	if (sock_raw < 0) {
		printf("Socket Error\n");
		return;
	}
	//---------------------------------------------------

	// write data to file-----------------------------------------------------------
	while (1)
	{
		// Receive a packet---------------------------------------------------
		saddr_size = sizeof saddr;
		data_size = recvfrom(sock_raw, buffer, 65536, 0, &saddr, &saddr_size);
		//--------------------------------------------------------------------

		//--------------------------------------------------------
		if (data_size < 0) {
			printf("Recvfrom error , failed to get packets\n");
			return;
		}
		//--------------------------------------------------------

		// Now process the packet----------------------------
		print_ip_header(buffer, data_size, existing_IP_list);
		//---------------------------------------------------
	}
	//------------------------------------------------------------------------------

	//---------------
	close(sock_raw);
	//---------------
}

void print_ip_header(unsigned char *Buffer, int Size, IP_list *existing_IP_list) {
	// variables--------------------------------
	unsigned short iphdrlen;

	struct iphdr *iph = (struct iphdr *)Buffer;
	iphdrlen = iph->ihl * 4;
	//------------------------------------------

	// memset----------------------------
	memset(&source, 0, sizeof(source));
	source.sin_addr.s_addr = iph->saddr;

	memset(&dest, 0, sizeof(dest));
	dest.sin_addr.s_addr = iph->daddr;
	//----------------------------------

	// write to file-----------------------------------------------------------------------------------------------------------------
	{
		fprintf(logfile, "\n----------------------------------------------------\n");
		fprintf(logfile, "   |-IP Version        : %d\n", (unsigned int)iph->version);
		fprintf(logfile, "   |-IP Header Length  : %d DWORDS or %d Bytes\n", (unsigned int)iph->ihl, ((unsigned int)(iph->ihl)) * 4);
		fprintf(logfile, "   |-Source IP         : %s\n", inet_ntoa(source.sin_addr));
		fprintf(logfile, "   |-Destination IP    : %s\n", inet_ntoa(dest.sin_addr));
		fprintf(logfile, "----------------------------------------------------\n");
	}
	//-------------------------------------------------------------------------------------------------------------------------------

	existing_IP_list->num_of_packets++;

	//-------------------------------------------------------
	FILE *read_command = fopen("num_of_packets.txt", "r");

	char comp[4] = { 0 };

	fgets(comp, 5, read_command);

	if(0 == strncmp("show", comp, 4)) {
		printf("num_of_packets = %d\n", existing_IP_list->num_of_packets);
	}

	read_command = fopen("num_of_packets.txt", "w");
	fclose(read_command);
	//-------------------------------------------------------
}

// about prog---------------------------------------------------------------------------
void about_prog() {
	puts("	------------------------------------------------------------------------");
	puts("	|                           NETWORK SNIFFER                            |");
	puts("	|   This program sniff network traffic and write to file:              |");
	puts("	|        1. IP Version                                                 |");
	puts("	|        2. IP Header Length                                           |");
	puts("	|        3. Source IP                                                  |");
	puts("	|        4. Destination IP                                             |");
	puts("	------------------------------------------------------------------------\n");

	puts("	--------------------------------	--------------------------------");
	puts("	|        FIRST COMMAND         |	|        SECOND COMMAND        |");
	puts("	--------------------------------	--------------------------------");
	puts("	|          --help              |	|            start             |");
	puts("	|                              |	|                              |");
	puts("	|     you can get some info    |	|     start programm after     |");
	puts("	|       about programm         |	|         stop command         |");
	puts("	--------------------------------	--------------------------------\n");

	puts("	--------------------------------	--------------------------------");
	puts("	|         THIRD COMMAND        |	|        FOURTH COMMAND        |");
	puts("	--------------------------------	--------------------------------");
	puts("	|             stop             |	|            break             |");
	puts("	|                              |	|                              |");
	puts("	|        stop sniffing         |	|    stop sniffing paсkages    |");
	puts("	|                              |	|     and exit the program     |");
	puts("	--------------------------------	--------------------------------\n");

	puts("	--------------------------------	--------------------------------");
	puts("	|         FIFTH COMMAND        |	|         SIXTH COMMAND        |");
	puts("	--------------------------------	--------------------------------");
	puts("	|             show             |	|             stat             |");
	puts("	|                              |	|                              |");
	puts("	|      show num of paсkets     |	|    show all collected stat   |");
	puts("	|                              |	|        for interface         |");
	puts("	--------------------------------	--------------------------------");
}
//--------------------------------------------------------------------------------------

// work with IP list-----------------------------------------------------------------------------
IP_list *createNodeForIPList(char *set_IP, unsigned set_num_of_packets)
{
	IP_list *node = (IP_list *)malloc(sizeof(IP_list));

	node->IP = set_IP;
	node->num_of_packets = set_num_of_packets;

	node->next = NULL;

	return node;
}
IP_list *pushNodeFront(IP_list **push_to_existing_IP_list, char *set_IP, unsigned set_num_of_packets)
{
	// if(NULL == push_to_existing_IP_list) return NULL;

	IP_list *newNode = createNodeForIPList(set_IP, set_num_of_packets);

	newNode->next = *push_to_existing_IP_list;
	*push_to_existing_IP_list = newNode;

	return newNode;
}
void printIPList(IP_list *IP_list_to_print)
{
	puts("-------------------------------------------------------");
	while (NULL != IP_list_to_print)
	{
		printf("IP = %s  |  num of packets = %d\n", IP_list_to_print->IP, IP_list_to_print->num_of_packets);
		IP_list_to_print = IP_list_to_print->next;
	}
	puts("-------------------------------------------------------");
}
//----------------------------------------------------------------------------------------------
